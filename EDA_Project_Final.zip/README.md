# Task 1: Exploratory Data Analysis (EDA) on Real-World Dataset

**Name:** Shivani Gundeti  
**Batch No:** 64R  
**GitHub Notebook Link:** [Task 1.ipynb](Task 1.ipynb)

---

## Project Overview

This project performs **Exploratory Data Analysis (EDA)** on a real-world e-commerce sales dataset. The main goal is to extract insights from sales, profit, discounts, and regional performance to understand business trends and patterns.

The dataset contains the following key features:  

- `Order ID` – Unique identifier for each order  
- `Customer ID` – Unique identifier for each customer  
- `Product Category` – Category of the product (e.g., Furniture, Technology, Office Supplies)  
- `Product Name` – Name of the product  
- `Order Date` – Date when the order was placed  
- `Ship Date` – Date when the order was shipped  
- `Sales` – Sales value of the order  
- `Quantity` – Number of products ordered  
- `Discount` – Discount applied on the order  
- `Profit` – Profit earned from the order  
- `Region` – Region where the order was delivered  

---

## Key EDA Steps

1. **Dataset Overview**  
   - Shape, basic info, head, and summary statistics  
   - Missing values check  

2. **Exploratory Visualizations**  
   - Sales count by region  
   - Total sales by product category  
   - Discount vs Profit by product category  
   - Monthly sales trend  

3. **Correlation Analysis**  
   - Correlation matrix of numerical variables  

4. **Insights**  
   - Identify highest-performing products and regions  
   - Understand the impact of discounts on profit  
   - Highlight monthly sales trends  

---

## Technologies Used

- Python 3  
- Pandas  
- NumPy  
- Matplotlib  
- Seaborn  

---

## How to Run

1. Download the dataset: `sales_data.csv`  
2. Open the `Task 1.ipynb` notebook in **Jupyter Notebook** or **Google Colab**  
3. Run all cells to perform the EDA and visualize the results  

---

## Insights (Sample)

- Highest sales may come from Technology products.  
- Profit decreases as discount increases for some categories.  
- The South region shows higher overall sales compared to other regions.  

*(Note: Replace insights after analyzing the actual dataset)*
